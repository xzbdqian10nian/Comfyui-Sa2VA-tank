# ComfyUI-Sa2VA Global Configuration
# Configuration settings for Sa2VA nodes

be_quiet = False  # Default to keep the console quiet for Sa2VA operations
